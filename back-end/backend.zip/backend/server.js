const express = require("express");
const cors = require("cors");
const app = express();
const PORT = 3000;

// Permitir conexión desde el frontend
app.use(cors());

// Ruta del BFF
app.get("/lugares", (req, res) => {
  res.json([
    {
      id: 1,
      name: "Museo del Oro",
      category: "Museo",
      lat: 4.601,
      lng: -74.072
    },
    {
      id: 2,
      name: "Monserrate",
      category: "Turismo",
      lat: 4.605,
      lng: -74.055
    }
  ]);
});

// Levantar servidor
app.listen(PORT, () => {
  console.log(`Servidor corriendo en http://localhost:${PORT}`);
});